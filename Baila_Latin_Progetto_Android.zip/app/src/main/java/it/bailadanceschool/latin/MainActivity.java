package it.bailadanceschool.latin;

import android.app.Activity;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.os.Bundle;
import android.net.Uri;
import android.graphics.Color;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.webkit.WebViewDatabase;
import java.io.InputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.HashMap;

public class MainActivity extends Activity {
    private static final String URL = "https://bailalatin.local/index.html";
    private static final int FILE_CHOOSER_REQUEST = 808;
    private WebView browser;
    private ValueCallback<Uri[]> pendingFileChooser;
    private View fullscreenView;
    private WebChromeClient.CustomViewCallback fullscreenCallback;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(12,17,23));
        getWindow().setNavigationBarColor(Color.rgb(12,17,23));
        browser = new WebView(this);
        browser.setBackgroundColor(Color.rgb(12,17,23));
        setContentView(browser);
        WebSettings settings = browser.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setDefaultTextEncodingName("utf-8");
        browser.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                return !"bailalatin.local".equals(req.getUrl().getHost());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri address = req.getUrl();
                if (!"bailalatin.local".equals(address.getHost())) return null;
                if (!"/index.html".equals(address.getPath()) && !"/".equals(address.getPath())) {
                    return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", new HashMap<String,String>(), new java.io.ByteArrayInputStream(new byte[0]));
                }
                try {
                    InputStream stream = getAssets().open("index.html");
                    Map<String,String> headers = new HashMap<>();
                    headers.put("Cache-Control", "no-cache");
                    return new WebResourceResponse("text/html", "utf-8", 200, "OK", headers, stream);
                } catch (IOException e) {
                    return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", new HashMap<String,String>(), new java.io.ByteArrayInputStream(new byte[0]));
                }
            }
        });
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(null);
                pendingFileChooser = callback;
                Intent chooser = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                chooser.addCategory(Intent.CATEGORY_OPENABLE);
                chooser.setType("*/*");
                chooser.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/*", "application/octet-stream"});
                chooser.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try { startActivityForResult(chooser, FILE_CHOOSER_REQUEST); return true; }
                catch (ActivityNotFoundException ex) { pendingFileChooser = null; return false; }
            }
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (fullscreenView != null) {callback.onCustomViewHidden(); return;}
                fullscreenView = view; fullscreenCallback = callback;
                ((android.view.ViewGroup) browser.getParent()).addView(view, new android.view.ViewGroup.LayoutParams(-1,-1));
                browser.setVisibility(View.GONE);
                getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
            }
            @Override public void onHideCustomView() {
                if (fullscreenView == null) return;
                android.view.ViewGroup parent = (android.view.ViewGroup) fullscreenView.getParent();
                if (parent != null) parent.removeView(fullscreenView);
                fullscreenView = null;
                browser.setVisibility(View.VISIBLE);
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
                if (fullscreenCallback != null) fullscreenCallback.onCustomViewHidden();
                fullscreenCallback = null;
            }
        });
        browser.loadUrl(URL);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode != FILE_CHOOSER_REQUEST || pendingFileChooser == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                result = new Uri[count];
                for (int i=0;i<count;i++) result[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        pendingFileChooser.onReceiveValue(result);
        pendingFileChooser = null;
    }
    @Override protected void onPause() { if (browser != null) browser.onPause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); if (browser != null) browser.onResume(); }
    @Override public void onBackPressed() {
        if (fullscreenView != null) {browser.getWebChromeClient().onHideCustomView(); return;}
        if (browser != null && browser.canGoBack()) { browser.goBack(); return; }
        super.onBackPressed();
    }
}
