BAILA LATIN - ANDROID

App indipendente da Baila Dance School (codice it.bailadanceschool.latin).
Icona: logo approvato Baila Latin rosso e bianco.
8 colonne, 15 tasti per colonna: 120 tasti MP3.
Rinomina colonne e tasti; play/pause; salti indietro e avanti di 10 s; scorrimento barra di avanzamento; velocita, volume e equalizzatore.
MP3 locali: ogni brano importato viene conservato nello storage interno privato della app tramite IndexedDB, se il dispositivo lo consente.
Salvataggi e brani di questa app separati dalla Baila Dance School preesistente.
Attenzione: disinstallare l'app cancella MP3 e collegamenti memorizzati internamente.

COMPILAZIONE
Compilare progetto con Java 17, Android Gradle Plugin 8.7.3, Gradle 8.10.2 e Android SDK 35; eseguire gradle :app:assembleDebug.
Altrimenti usare il file compila-baila-latin.yml caricandolo nella cartella .github/workflows del repository GitHub: crea e pubblica l'APK, senza un PC.

Questa ZIP e un progetto sorgente, NON un APK installabile.
