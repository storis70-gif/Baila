# Baila Dance School — progetto Android

La base è l'ULTIMO PAD HTML `siro_SENZA_DOPPIONI_SALVA_COLLEGAMENTI.html`, copiato senza riscriverne i comandi in `app/src/main/assets/index.html`. Restano 120 tasti, 8 colonne, controlli audio, controllo doppioni, associazione per nome, salvataggio locale in IndexedDB, ZIP portatile, ecc.

## Come compilare con GitHub Actions
1. Carica l'intero contenuto di questa cartella nel repository `storis70-gif/Baila`, mantenendo le sottocartelle compresa `.github/workflows`.
2. Vai in **Actions**: seleziona **Crea APK Baila**, poi **Run workflow** (oppure attendi l'avvio automatico dopo il caricamento).
3. Al termine apri il workflow e scarica l'artifact `Baila-Dance-School-APK`.
4. Estrai lo ZIP dell'artifact e installa `app-debug.apk` sul tablet Android.

## Da sapere
- Gli MP3 **non sono inclusi**, perché non sono presenti nel file HTML. I vecchi percorsi `canzoni/tasto_N.mp3` non diventano file audio automaticamente in Android: importa i tuoi MP3 nei tasti e premi **SALVA TASTI + CANZONI**. Vengono conservati nell'archivio interno IndexedDB dell'app. Non cancellare dati dell'app senza backup.
- La funzione **Esporta cartella ZIP** originaria usa un download `blob:`: in questa versione Android WebView il download potrebbe non funzionare. Rimane presente nell'interfaccia per fedeltà all'originale ma va verificato sul tablet.
- L'APK prodotto è una versione **debug** per prove personali, non una release Play Store.
- Questo progetto non è stato ancora compilato e provato su un dispositivo Android: eventuali problemi vanno verificati dopo la build.
